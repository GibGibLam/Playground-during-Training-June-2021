package com.fdmgroup.BankDesign;

public class BusinessSavings extends Savings {

}
