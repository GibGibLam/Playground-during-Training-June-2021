package com.fdmgroup.BankDesign;

public class BusinessCurrent extends Current {

}
