package com.fdmgroup.BankDesign;

public class PersonalSavings extends Savings {

}
