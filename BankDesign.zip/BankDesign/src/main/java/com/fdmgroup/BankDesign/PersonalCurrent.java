package com.fdmgroup.BankDesign;

public class PersonalCurrent extends Current {

}
